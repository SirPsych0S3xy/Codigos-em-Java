package Empresa;

import java.util.ArrayList;
// Import do ArrayList

class Cofrinho {
    private ArrayList<Moeda> moedas;

    public Cofrinho() {
        moedas = new ArrayList<>();
    }

    public void adicionarMoeda(Moeda moeda) {
        moedas.add(moeda);
        System.out.println("Moeda adicionada ao cofrinho: " + moeda);
    }

    public void removerMoeda(String nome) {
        for (int i = 0; i < moedas.size(); i++) {
            if (moedas.get(i).getNome().equalsIgnoreCase(nome)) {
                Moeda moedaRemovida = moedas.remove(i);
                System.out.println("Moeda removida do cofrinho: " + moedaRemovida);
                return;
            }
        }
        System.out.println("Moeda não encontrada no cofrinho.");
    }

    public void listarMoedas() {
        if (moedas.isEmpty()) {
            System.out.println("Cofrinho vazio.");
        } else {
            System.out.println("Moedas no cofrinho:");
            for (Moeda moeda : moedas) {
                System.out.println("- " + moeda);
            }
        }
    }

    public double calcularTotalEmReais() {
        double total = 0;
        for (Moeda moeda : moedas) {
            if (moeda instanceof Real) {
                total += moeda.getValor();
            } else if (moeda instanceof Dolar) {
                total += moeda.getValor() * 5.5; 
                // Taxa de conversão de 1 Dólar = 5.5 Reais
            } else if (moeda instanceof Euro) {
                total += moeda.getValor() * 6.5; 
                // Taxa de conversão de 1 Euro = 6.5 Reais
            }
        }
        return total;
    }
}