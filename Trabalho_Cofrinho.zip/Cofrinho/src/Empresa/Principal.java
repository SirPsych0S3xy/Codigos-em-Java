package Empresa;

import java.util.Scanner;
//Import do Scanner

// Classe Principal
public class Principal {

	public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)){
        Cofrinho cofrinho = new Cofrinho();

     // Loop para exibir o menu de interação com o usuário
        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Adicionar moeda");
            System.out.println("2. Remover moeda");
            System.out.println("3. Listar as moedas");
            System.out.println("4. Calcular total das moedas em Reais");
            System.out.println("5. Sair");

            System.out.print("Escolha uma das opçôes: ");
            int opcao = scanner.nextInt();

         // Switch case para cada opção do menu
            switch (opcao) {
                case 1:
                    System.out.print("Qual moeda deseja adicionar (Dólar/Euro/Real): ");
                    String nomeMoeda = scanner.next();
                    System.out.print("Qual valor da moeda deseja adicionar: ");
                    double valorMoeda = scanner.nextDouble();
                    Moeda novaMoeda;
                    switch (nomeMoeda.toLowerCase()) {
                        case "dólar":
                            novaMoeda = new Dolar(valorMoeda);
                            break;
                        case "euro":
                            novaMoeda = new Euro(valorMoeda);
                            break;
                        case "real":
                            novaMoeda = new Real(valorMoeda);
                            break;
                        default:
                            System.out.println("Moeda inválida.");
                            continue;
                    }
                    cofrinho.adicionarMoeda(novaMoeda);
                    break;
                case 2:
                    System.out.print("Qual moeda deseja remover?: ");
                    String nomeMoedaRemover = scanner.next();
                    cofrinho.removerMoeda(nomeMoedaRemover);
                    break;
                case 3:
                    cofrinho.listarMoedas();
                    break;
                case 4:
                    System.out.printf("Valor total das moedas convertidas em Reais no cofrinho: " + "%.2f", cofrinho.calcularTotalEmReais());
                    System.out.println(" ");
                    break;
                case 5:
                    System.out.println("Encerrado programa cofrinho...");
                    System.exit(0);
                default:
                    System.out.println("Opção inválida.");
            }
        }
        }       
	}
	
}