package Empresa;

// Classe dolar filha da Classe Moeda
class Dolar extends Moeda {
    public Dolar(double valor) {
        super("Dólar", valor);
    }

    // Implementação da conversão para Real
    @Override
    public double converterParaReal() {
        return valor * 5.5; 
        // Taxa de conversão de 1 Dólar = 5.5 Reais
    }
}


