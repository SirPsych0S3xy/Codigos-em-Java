package Empresa;

//Classe Euro filha da Classe Moeda2
class Euro extends Moeda {
 public Euro(double valor) {
     super("Euro", valor);
 }

 // Implementação da conversão para Real
 @Override
 public double converterParaReal() {
     return valor * 6.5; 
     // Taxa de conversão de 1 Euro = 6.5 Reais
 }
}

