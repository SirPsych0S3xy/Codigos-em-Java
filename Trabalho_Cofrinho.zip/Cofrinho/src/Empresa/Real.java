package Empresa;

//Classe Real filha da Classe Moeda
class Real extends Moeda {
 public Real(double valor) {
     super("Real", valor);
 }

 // Implementação da conversão para Real
 @Override
 public double converterParaReal() {
     return valor;
 }
}
