package Empresa;

//Classe abstrata Moeda
abstract class Moeda {
 protected String nome;
 protected double valor;

 // Construtor
 public Moeda(String nome, double valor) {
     this.nome = nome;
     this.valor = valor;
 }

 // Método abstrato para converter moeda para Real
 public abstract double converterParaReal();

 // Métodos getters
 public String getNome() {
     return nome;
 }

 public double getValor() {
     return valor;
 }

 // Método toString para representação da moeda
 @Override
 public String toString() {
     return nome + " (" + valor + ")";
 }
}

